import { RawOptions } from '../types/interfaces';
declare const defaultOptions: RawOptions;
export default defaultOptions;
